import { Component, OnInit } from '@angular/core';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-show',
  templateUrl: './vendor-show.component.html',
  styleUrls: ['./vendor-show.component.css']
})
export class DriverShowComponent implements OnInit {
  drivers : Vendor[];

  constructor(private _driverService:VendorService) {

    this._driverService.showVendor().subscribe(x => {
      this.drivers=x;
    })
   }


  ngOnInit(): void {
  }

}
