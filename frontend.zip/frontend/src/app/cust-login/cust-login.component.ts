import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustService } from '../cust.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-cust-login',
  templateUrl: './cust-login.component.html',
  styleUrls: ['./cust-login.component.css']
})
export class UserLoginComponent implements OnInit {
  userName : string;
  passCode : string;
  myForm: FormGroup;

  login() {
    this._userService.custAuthenticate(this.userName,this.passCode).subscribe(x =>{
      if (x=="1") {
        localStorage.setItem("userUser",this.userName);
        this._router.navigate(['/userDashBoard']);
        
      }
      else if(this.userName==" "|| this.passCode==" "){
        alert("Fill the details");
      }
      else{
        alert("invalid credentials");
      }
    })

    // localStorage.setItem("manager","Srinivas");
    // if (this.userName=="Sainath" && this.passCode=="Sainath") {
    //   this._router.navigate(['/customer-dash-board']);
    // }
  }
  showAlertIfEmpty() {
    if (!this.myForm.valid) {
        alert("Please fill in all required fields.");
    }
}
  constructor(private _router : Router,private _userService :CustService,) {
  //   this.myForm = this.formBuilder.group({
  //     userName: ['', Validators.required], // Ensure username is not empty
  //     passCode: ['', Validators.required] // Ensure password is not empty
  // });
   }

  ngOnInit(): void {
  }

}
