import { Component, OnInit } from '@angular/core';
import { Cust } from '../cust';
import { CustService} from '../cust.service';

@Component({
  selector: 'app-user-dash-board',
  templateUrl: './user-dash-board.component.html',
  styleUrls: ['./user-dash-board.component.css']
})
export class UserDashBoardComponent implements OnInit {

 // manager : string;
  user : Cust;
  user1 : string;
  constructor(private _userService:CustService) {
    //this.manager = localStorage.getItem("manager")
    //this.manager = localStorage.getItem("manager")
    this.user1 = localStorage.getItem("userUser")
    this._userService.searchByUserName(this.user1).subscribe(x => {
      this.user=x;
      localStorage.setItem("user",x.userId.toString())//vendorid
    })
   }


  ngOnInit(): void {
  }

}
