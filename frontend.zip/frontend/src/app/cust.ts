export class Cust {
    public userId : number;
    public userName : string;
    public passCode : string;
    public firstName : string;
    public lastName : string;
    public city: string;
    public state: string;
    public mobile: string;
    public email: string;
    constructor() {
    }

}
