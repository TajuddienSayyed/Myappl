import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Booking } from './booking';
import { Vendor } from './vendor';

@Injectable({
  providedIn: 'root'
})
export class VendorService {
  public showVendor() : Observable<Vendor[]> {
    return this._http.get<Vendor[]>("http://localhost:1111/showVendorDetails")
  }
  public showVendorBookings() : Observable<Booking[]> {
    return this._http.get<Booking[]>("http://localhost:1111/showvendorBooking")
  }
  public vendorAuthenticate(user : string, pwd:string) : Observable<string> {
    return this._http.get<string>("http://localhost:1111/Authenticate/"+user+ "/" +pwd)

  }
  public searchByUserName(user : string) : Observable<Vendor> {
    return this._http.get<Vendor>("http://localhost:1111/searchByVendorUserName/"+user)
  }

  public showVendorBooking(bid : number) : Observable<Booking[]> {
    return this._http.get<Booking[]>("http://localhost:1111/showVendorBookings/"+bid)
  }
  

  constructor(private _http : HttpClient) { }
}
