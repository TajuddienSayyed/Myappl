
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { Booking } from './booking';
import { Cust } from './cust';

@Injectable({
  providedIn: 'root'
})
export class CustService {
  public showCust() : Observable<Cust[]> {
    return this._http.get<Cust[]>("http://localhost:1111/showCustDetails")
  }
  public showBooking() : Observable<Booking[]> {
    return this._http.get<Booking[]>("http://localhost:1111/showBooking")
  }
  public custAuthenticate(user : string, pwd:string) : Observable<string> {
    return this._http.get<string>("http://localhost:1111/userAuthenticate/"+user+ "/" +pwd)

  }
  public searchByUserName(user : string) : Observable<Cust> {
    return this._http.get<Cust>("http://localhost:1111/searchByCustName/"+user)
  }
  public showUserBooking(bid : number) : Observable<Booking[]> {
    return this._http.get<Booking[]>("http://localhost:1111/showUserBookings/"+bid)
  }
  public bookOrder(booking : Booking){
    return this._http.post("http://localhost:1111/bookOrder", booking);
  }
  public acceptRejectBooking(bid : number,status: string) { 
    return this._http.post("http://localhost:1111/confirmOrder/"+bid+"/"+status,null)
   }
  constructor(private _http:HttpClient) { }
}
