import { Component, OnInit } from '@angular/core';
import { Booking } from '../booking';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-user-booking',
  templateUrl: './user-booking.component.html',
  styleUrls: ['./user-booking.component.css']
})
export class UserBookingComponent implements OnInit {

  bookings : Booking[];
  cid : number;
  // constructor(private _userService : CustService) { 
  //   this.cid=parseInt(localStorage.getItem("cid"));
  //   this._userService.showUserBooking(this.cid).subscribe(x => {
  //     this.bookings = x;
  //   })
  // }
  users : Booking[];

  constructor(private _userService:CustService) {

    this._userService.showBooking().subscribe(x => {
      this.bookings=x;
    })
   }


  ngOnInit(): void {
  }

}
