import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-accept-reject-booking',
  templateUrl: './accept-reject-booking.component.html',
  styleUrls: ['./accept-reject-booking.component.css']
})
export class AcceptRejectBookingComponent implements OnInit {
  bid : number;
  status : string;
  constructor(private _userservice:CustService) { }
  result : any;
  acceptReject() {
    this._userservice.acceptRejectBooking(this.bid,this.status).subscribe(x => {
      this.result=x;
    })
  }

  ngOnInit(): void {
  }

}
