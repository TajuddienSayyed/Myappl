import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcceptRejectBookingComponent } from './accept-reject-booking.component';

describe('AcceptRejectBookingComponent', () => {
  let component: AcceptRejectBookingComponent;
  let fixture: ComponentFixture<AcceptRejectBookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcceptRejectBookingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcceptRejectBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
