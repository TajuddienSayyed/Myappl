export class Booking {
    public  orderId:number;
	public userId:number;
	public vendorID:number;
	public  orderDate:Date;
	public  orderName:string;
	public  orderStatus:string;
	public  price:DoubleRange;
    constructor() {
    }
}
