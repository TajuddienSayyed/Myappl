import { Cust} from './cust';

describe('User', () => {
  it('should create an instance', () => {
    expect(new Cust()).toBeTruthy();
  });
});
