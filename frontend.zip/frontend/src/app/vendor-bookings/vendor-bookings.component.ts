import { Component, OnInit } from '@angular/core';
import { Booking } from '../booking';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-bookings',
  templateUrl: './vendor-bookings.component.html',
  styleUrls: ['./vendor-bookings.component.css']
})
export class VendorBookingsComponent implements OnInit {

  bookings : Booking[];
  cid : number;
  constructor(private _customerService : VendorService) { 
    //this.cid=parseInt(localStorage.getItem("cid"));
    // this._customerService.showVendorBooking(this.cid).subscribe(x => {
    //   this.bookings = x;
    // })
    this._customerService.showVendorBookings().subscribe(x => {
      this.bookings=x;
    })
  }

  ngOnInit(): void {
  }

}
