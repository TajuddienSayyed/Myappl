export class Vendor {
    public vendorId : number;
    public vendoruserName : string;
    public vendorpassword : string;
    public vendorfirstName: string;
    public vendorlastName : string;
        constructor() {}

}
