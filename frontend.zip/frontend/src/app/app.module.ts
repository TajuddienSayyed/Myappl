import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserLoginComponent } from './cust-login/cust-login.component';
import { UserDashBoardComponent } from './user-dash-board/user-dash-board.component';
import { UserShowComponent } from './user-show/user-show.component';
import { VendorShowComponent } from './vendor-show/vendor-show.component';
import { VendorLoginComponent } from './vendor-login/vendor-login.component';
import { VendorDashBoardComponent } from './vendor-dash-board/vendor-dash-board.component';
import { UserBookingComponent } from './user-booking/user-booking.component';
import { VendorBookingsComponent } from './vendor-bookings/vendor-bookings.component';
import { BookOrderComponent } from './book-order/book-order.component';
import { AcceptRejectBookingComponent } from './accept-reject-booking/accept-reject-booking.component';
const routes : Routes =
 [
  {path:'',component:HomeComponent},
  {path:'custLogin',component:UserLoginComponent},
  {path:'userDashBoard',component:UserDashBoardComponent},
  {path:'vendorLogin',component:VendorLoginComponent},
  {path:'vendorDashBoard',component:VendorDashBoardComponent,
  
    children: 
    [
      {path:'vendorShow',component:VendorShowComponent,outlet:'cbs'},
      {path:'vendorBookings',component:VendorBookingsComponent,outlet:'cbs'},
      {path:'acceptReject',component:AcceptRejectBookingComponent,outlet:'cbs'},

    ]
  }, 
  {path:'userDashBoard',component:UserDashBoardComponent,
  children:
  [
    {path:'userShow',component:UserShowComponent,outlet:'cbs'},
    {path:'userBookings',component:UserBookingComponent,outlet:'cbs'},
    {path:'userBookOrder',component:BookOrderComponent,outlet:'cbs'},
  ]

}
]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserLoginComponent,
    UserDashBoardComponent,
    UserShowComponent,
  
    VendorShowComponent,
    VendorLoginComponent,
    VendorDashBoardComponent,
    UserBookingComponent,
    VendorBookingsComponent,
    BookOrderComponent,
    AcceptRejectBookingComponent,


  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
