import { Component, OnInit } from '@angular/core';
import { Booking } from '../booking';
import { Cust } from '../cust';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-book-order',
  templateUrl: './book-order.component.html',
  styleUrls: ['./book-order.component.css']
})
export class BookOrderComponent implements OnInit {
  cid : number;
  vid : Date;
  mid : number;
  walSource : number;
  customer : Cust;
  orders : Booking;
  end: string;
  ordc : number;
  ord: DoubleRange;
  result : any;
  start: string;
  constructor(private _customerService : CustService) {
    this.orders= new Booking();
    this.cid= parseInt(localStorage.getItem("userid"))
   }
   bookOrder() {
    //this.orders.bookingId=this.cid;
    this.orders.orderDate=this.vid;
    this.orders.orderId=this.mid;
    this.orders.orderName=this.start;
    this.orders.userId=this.cid;
    this.orders.orderStatus="PLACED";
    this.orders.price=this.ord;
    this._customerService.bookOrder(this.orders).subscribe(x => {
        this.result=x;
    })
  }

  ngOnInit(): void {
  }
}

