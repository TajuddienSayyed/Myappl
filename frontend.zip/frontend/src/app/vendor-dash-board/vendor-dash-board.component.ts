import { Component, OnInit } from '@angular/core';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-dash-board',
  templateUrl: './vendor-dash-board.component.html',
  styleUrls: ['./vendor-dash-board.component.css']
})
export class VendorDashBoardComponent implements OnInit {
  vendor: Vendor;
  driver1 : string;
  constructor(private _driverService:VendorService) {
    //this.manager = localStorage.getItem("manager")
    //this.manager = localStorage.getItem("manager")
    this.driver1 = localStorage.getItem("vendorUser")
    this._driverService.searchByUserName(this.driver1).subscribe(x => {
      this.vendor=x;
      localStorage.setItem("vendor",x.vendorId.toString())
    })
   }

  ngOnInit(): void {
  }

}
