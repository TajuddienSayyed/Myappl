import { Component, OnInit } from '@angular/core';
import { Cust } from '../cust';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-user-show',
  templateUrl: './user-show.component.html',
  styleUrls: ['./user-show.component.css']
})
export class UserShowComponent implements OnInit {

  users : Cust[];

  constructor(private _userService:CustService) {

    this._userService.showCust().subscribe(x => {
      this.users=x;
    })
   }


  ngOnInit(): void {
  }

}
