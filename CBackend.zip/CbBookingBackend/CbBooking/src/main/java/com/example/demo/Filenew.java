package com.example.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Filenew {

    // Step 1: Fetch data from public API for the last one week
    public static JSONArray fetchWeatherData() {
        String apiKey = "5f6eebe61c128e72f32a4d6324cf73ce";
        List<String> cities = Arrays.asList("Mumbai", "Delhi", "Bangalore", "Kolkata", "Chennai");
        JSONArray weatherData = new JSONArray();
        
        // Calculate start and end timestamps for last one week
        Instant endTimestamp = Instant.now();
        Instant startTimestamp = endTimestamp.minus(7, ChronoUnit.DAYS);
        System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
        for (String city : cities) {
            String urlString = "https://api.openweathermap.org/data/2.5/forecast?q=" + city + ",IN&appid=" + apiKey + "&units=metric&start=" + startTimestamp.getEpochSecond() + "&end=" + endTimestamp.getEpochSecond();

            try {
                // Create URL object
                URL url = new URL(urlString);

                // Create HttpURLConnection object
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                // Read response
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // Parse JSON response and add to weatherData JSONArray
                weatherData.put(new JSONObject(response.toString()));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        return weatherData;
    }

    // Step 2: Clean and manipulate data
    public static JSONArray cleanData(JSONArray weatherData) {
        JSONArray cleanedData = new JSONArray();

        for (Object obj : weatherData) {
            JSONObject data = (JSONObject) obj;
            String city = data.getJSONObject("city").getString("name");
            JSONArray list = data.getJSONArray("list");

            double sum = 0;
            for (int i = 0; i < list.length(); i++) {
                JSONObject entry = list.getJSONObject(i);
                double temp = entry.getJSONObject("main").getDouble("temp");
                sum += temp;
            }
            double avgTemp = sum / list.length();

            JSONObject cleanedObj = new JSONObject();
            cleanedObj.put("City", city);
            cleanedObj.put("Average Temperature", avgTemp);
            cleanedData.put(cleanedObj);
        }

        return cleanedData;
    }

    // Step 3: Generate report
    public static JSONArray generateReport(JSONArray cleanedData) {
        JSONArray report = new JSONArray();

        for (Object obj : cleanedData) {
            JSONObject data = (JSONObject) obj;
            String city = data.getString("City");
            double avgTemp = data.getDouble("Average Temperature");
            String severity;
            if (avgTemp > 40) {
                severity = "Red Alert";
            } else if (avgTemp >= 35 && avgTemp <= 40) {
                severity = "Orange Alert";
            } else {
                severity = "Green";
            }

            JSONObject reportObj = new JSONObject();
            reportObj.put("City", city);
            reportObj.put("Average Temperature", avgTemp);
            reportObj.put("Severity", severity);
            report.put(reportObj);
        }

        return report;
    }

    // Step 4: Save report to MySQL
    public static void saveReportToMySQL(JSONArray report) {
    	//System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
        String url = "jdbc:mysql://localhost:3306/weather";
        String user = "root";
        String password = "root";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String insertQuery = "INSERT INTO Citydata (CityName, AvgTemp, Severity) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);

            for (int i = 0; i < report.length(); i++) {
                JSONObject data = report.getJSONObject(i);
                preparedStatement.setString(1, data.getString("City"));
                preparedStatement.setDouble(2, data.getDouble("Average Temperature"));
                preparedStatement.setString(3, data.getString("Severity"));
                preparedStatement.executeUpdate();
            }
            System.out.println("Report saved to MySQL successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            JSONArray weatherData = fetchWeatherData();
            JSONArray cleanedData = cleanData(weatherData);
            JSONArray report = generateReport(cleanedData);
            saveReportToMySQL(report);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
