package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class CustDetailsDAO {

	@Autowired  
    JdbcTemplate jdbc;  

	public String authenticate(String user,String pwd) {
		String cmd = "select count(*) cnt from CustDetails where UserName=? "
				+ " AND PassCode=?";
		List str=jdbc.query(cmd,new Object[] {user,pwd}, new RowMapper() {
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getInt("cnt");
			}
			
		});
		return str.get(0).toString();
	}
	
	public CustDetails searchByCustName(String custName) {
		String cmd = "select * from CustDetails where UserName=?";
		List<CustDetails> listUsers=jdbc.query(cmd, new Object[] {custName}, new RowMapper<CustDetails>() {

			@Override
			public CustDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				CustDetails custDetails = new CustDetails();
				custDetails.setUserId(rs.getInt("custId"));
				custDetails.setUserName(rs.getString("userName"));
				custDetails.setPassCode(rs.getString("passCode"));
				custDetails.setFirstName(rs.getString("firstName"));
				custDetails.setLastName(rs.getString("lastName"));
				custDetails.setCity(rs.getString("city"));
				custDetails.setState(rs.getString("State"));
				custDetails.setEmail(rs.getString("email"));
				custDetails.setMobile(rs.getString("mobile"));
				return custDetails;
			}
			
		});
		return listUsers.get(0);
	}

	
	public CustDetails searchByCustId(int userId) {
		String cmd = "select * from CustDetails where CustId=?";
		List<CustDetails> listUsers=jdbc.query(cmd, new Object[] {userId}, new RowMapper<CustDetails>() {

			@Override
			public CustDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				CustDetails custDetails = new CustDetails();
				custDetails.setUserId(rs.getInt("custId"));
				custDetails.setUserName(rs.getString("userName"));
				custDetails.setFirstName(rs.getString("firstName"));
				custDetails.setLastName(rs.getString("lastName"));
				custDetails.setPassCode(rs.getString("passCode"));
				custDetails.setCity(rs.getString("city"));
				custDetails.setState(rs.getString("State"));
				custDetails.setEmail(rs.getString("email"));
				custDetails.setMobile(rs.getString("mobile"));
				return custDetails;
			}
			
		});
		return listUsers.get(0);
	}
	public List<CustDetails> showCustDetails() {
		String cmd = "select * from CustDetails";
		List<CustDetails> listUsers=jdbc.query(cmd, new RowMapper<CustDetails>() {

			@Override
			public CustDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				CustDetails custDetails = new CustDetails();
				custDetails.setUserId(rs.getInt("custId"));
				custDetails.setUserName(rs.getString("userName"));
				custDetails.setPassCode(rs.getString("passCode"));
				custDetails.setFirstName(rs.getString("firstName"));
				custDetails.setLastName(rs.getString("lastName"));
				custDetails.setCity(rs.getString("city"));
				custDetails.setState(rs.getString("State"));
				custDetails.setEmail(rs.getString("email"));
				custDetails.setMobile(rs.getString("mobile"));
				return custDetails;
			}
			
		});
		return listUsers;
	}
	public List<Order> showBookings() {
		String cmd = "select * from orderdetails";
		List<Order> listUsers=jdbc.query(cmd, new RowMapper<Order>() {

			@Override
			public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order custDetails = new Order();
				custDetails.setOrderId(rs.getInt("OrderId"));
				custDetails.setUserId(rs.getInt("CustId"));
				custDetails.setVendorID(rs.getInt("VendorId"));
				custDetails.setOrderName(rs.getString("OrderName"));
				custDetails.setOrderDate(rs.getDate("OrderDate"));
				custDetails.setPrice(rs.getDouble("price"));
				custDetails.setOrderStatus(rs.getString("OrderStatus"));
				return custDetails;
			}
			
		});
		return listUsers;
	}
	
	public Order searchBooking(int bookingId) {
		String cmd = "select * from orderdetails where OrderId=?";
		List<Order> listUsers=jdbc.query(cmd, new Object[] {bookingId}, new RowMapper<Order>() {

			@Override
			public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order booking = new Order();
				booking.setOrderId(rs.getInt("OrderId"));
				booking.setUserId(rs.getInt("CustId"));
				booking.setVendorID(rs.getInt("VendorId"));
				booking.setOrderDate(rs.getDate("OrderDate"));
				booking.setOrderName(rs.getString("OrderName"));
				booking.setOrderStatus(rs.getString("OrderStatus"));
				booking.setPrice(rs.getDouble("price"));
				
				return booking;
			}
			
		});
		return listUsers.get(0);

	}
	
	public List<Order> userBooking(int custId) {
		String cmd = "select * from orderdetails where CustId=?";
		List<Order> listUsers=jdbc.query(cmd, new Object[] {custId}, new RowMapper<Order>() {

			@Override
			public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order booking = new Order();
				booking.setOrderId(rs.getInt("orderId"));
				booking.setUserId(rs.getInt("CustId"));
				booking.setVendorID(rs.getInt("vendorID"));
				booking.setOrderDate(rs.getDate("orderDate"));
				booking.setOrderName(rs.getString("orderName"));
				booking.setOrderStatus(rs.getString("orderStatus"));
				booking.setPrice(rs.getDouble("price"));
				return booking;
			}
			
		});
		return listUsers;
		
	}
	
	public String bookOrder(Order booking) {
		String cmd = "Insert into OrderDetails(OrderId,CustId,VendorId,OrderDate,OrderName,OrderStatus,price)"
				+ " values(?,?,?,?,?,?,?)";
		jdbc.update(cmd, new Object[] {
				booking.getOrderId(),
				booking.getUserId(),
				booking.getVendorID(),
				booking.getOrderDate(),
				booking.getOrderName(),
				booking.getOrderStatus(),
				booking.getPrice()
				});
		return "Waiting for Confirmation...";
	}
	
}
