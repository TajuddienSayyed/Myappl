package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VendorDetailsController {

	@Autowired
	private VendorDetailsDAO dao;
	

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/showVendorDetails")
	public List<VendorDetails> list() {
		return dao.showVendorDetails();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/showvendorBooking")
	public List<Order> list2() {
		return dao.showvendorBookings();
	}


	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/Authenticate/{user}/{pwd}")
	public String autneticateion(@PathVariable String user, @PathVariable String pwd) {
		return dao.authenticate(user, pwd);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/searchVendorDetails/{id}")
	public VendorDetails searchById(@PathVariable int id) {
		return dao.searchByVendorId(id);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/searchByVendorUserName/{vendoruserName}")
	public VendorDetails searchById(@PathVariable String vendoruserName) {
		return dao.searchByVendorUserName(vendoruserName);
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value="/confirmOrder/{orderId}/{status}")
	public String confirmOrder(@PathVariable int orderId, @PathVariable String status) {
		return dao.acceptRejectOrder(orderId, status);
	}
		@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/showVendorBookings/{id}")
	public List<Order> VendorBookings(@PathVariable int id) {
		return dao.vendorBooking(id);
	}
}
