package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class VendorDetailsDAO {

	@Autowired  
    JdbcTemplate jdbc;  
	


	public VendorDetails searchByVendorUserName(String vendoruserName) {
		String cmd = "select * from VendorDetails where VendorUserName=?";
		List<VendorDetails> listUsers=jdbc.query(cmd, new Object[] {vendoruserName},  new RowMapper<VendorDetails>() {

			@Override
			public VendorDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				VendorDetails vendorDetails = new VendorDetails();
				vendorDetails.setVendorId(rs.getInt("VendorId"));
				vendorDetails.setVendoruserName(rs.getString("VendorUserName"));
				vendorDetails.setVendorpassword(rs.getString("VendorPassword"));
				vendorDetails.setVendorfirstName(rs.getString("VendorFirstName"));
				vendorDetails.setVendorlastName(rs.getString("VendorLastName"));
				return vendorDetails;
			}
			
		});
		return listUsers.get(0);
	}
	public String authenticate(String user,String pwd) {
		String cmd = "select count(*) cnt from VendorDetails where VendorUserName=? "
				+ " AND VendorPassword=?";
		List str=jdbc.query(cmd,new Object[] {user,pwd}, new RowMapper() {
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getInt("cnt");
			}
			
		});
		return str.get(0).toString();
	}
	
	public VendorDetails searchByVendorId(int vendorId) {
		String cmd = "select * from VendorDetails where VendorId=?";
		List<VendorDetails> listUsers=jdbc.query(cmd, new Object[] {vendorId}, new RowMapper<VendorDetails>() {

			@Override
			public VendorDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				VendorDetails vendorDetails = new VendorDetails();
				vendorDetails.setVendorId(rs.getInt("VendorId"));
				vendorDetails.setVendoruserName(rs.getString("VendorUserName"));
				vendorDetails.setVendorpassword(rs.getString("VendorPassword"));
				vendorDetails.setVendorfirstName(rs.getString("VendorFirstName"));
				vendorDetails.setVendorlastName(rs.getString("VendorLastName"));
				return vendorDetails;
			}
			
		});
		return listUsers.get(0);
	}
	public List<VendorDetails> showVendorDetails() {
		String cmd = "select * from VendorDetails";
		List<VendorDetails> listUsers=jdbc.query(cmd, new RowMapper<VendorDetails>() {

			@Override
			public VendorDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				VendorDetails vendorDetails = new VendorDetails();
				vendorDetails.setVendorId(rs.getInt("VendorId"));
				vendorDetails.setVendoruserName(rs.getString("VendorUserName"));
				vendorDetails.setVendorpassword(rs.getString("VendorPassword"));
				vendorDetails.setVendorfirstName(rs.getString("VendorFirstName"));
				vendorDetails.setVendorlastName(rs.getString("VendorLastName"));
				
				return vendorDetails;
			}
			
		});
		return listUsers;
	}
	public List<Order> showvendorBookings() {
		String cmd = "select * from orderdetails";
		List<Order> listUsers=jdbc.query(cmd, new RowMapper<Order>() {

			@Override
			public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order vendorDetails = new Order();
				vendorDetails.setOrderId(rs.getInt("OrderId"));
				vendorDetails.setOrderName(rs.getString("OrderName"));
				vendorDetails.setOrderDate(rs.getDate("OrderDate"));
				vendorDetails.setPrice(rs.getDouble("price"));
				vendorDetails.setOrderStatus(rs.getString("OrderStatus"));
				
				return vendorDetails;
			}
			
		});
		return listUsers;
	}
	
	public String acceptRejectOrder(int orderId, String status) {
	if (status.trim().equals("YES")) {
		String cmd = "Update Orderdetails set OrderStatus='CONFIRMED' WHERE OrderId=?";
		jdbc.update(cmd, new Object[] {orderId});
		return "Booking Confirmed...";
	}
//	else if (status.trim().equals("NO")) {
//		String cmd = "Update Orderdetails set OrderStatus='CANCELLED' WHERE OrderId=?";
//		jdbc.update(cmd, new Object[] {orderId});
//		return "Booking Cancelled...";
//	}
	else
	{
		String cmd = "Update Orderdetails set OrderStatus='CANCELLED' WHERE OrderId=?";
		jdbc.update(cmd, new Object[] {orderId});
		return "Booking Cancelled...";
	}
}
	public List<Order> vendorBooking(int custId) {
	String cmd = "select * from Orderdetails where CustId=?";
	List<Order> listUsers=jdbc.query(cmd, new Object[] {custId}, new RowMapper<Order>() {

		@Override
		public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
			Order booking = new Order();
			booking.setOrderId(rs.getInt("OrderId"));
			booking.setUserId(rs.getInt("CustId"));
			booking.setVendorID(rs.getInt("VendorId"));
			booking.setOrderDate(rs.getDate("OrderDate"));
			booking.setOrderName(rs.getString("OrderName"));
			booking.setOrderStatus(rs.getString("OrderStatus"));
			booking.setPrice(rs.getDouble("price"));
			
			return booking;
		}
		
	});
	return listUsers;
	
}
}
