package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustDetailsController {

	@Autowired
	private CustDetailsDAO dao;
	

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/showCustDetails")
	public List<CustDetails> list() {
		return dao.showCustDetails();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/showBooking")
	public List<Order> list2() {
		return dao.showBookings();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/showUserBookings/{id}")
	public List<Order> userBookings(@PathVariable int id) {
		return dao.userBooking(id);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/userAuthenticate/{user}/{pwd}")
	public String autneticateion(@PathVariable String user, @PathVariable String pwd) {
		return dao.authenticate(user, pwd);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/searchCustDetails/{id}")
	public CustDetails searchById(@PathVariable int id) {
		return dao.searchByCustId(id);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/searchByCustName/{custName}")
	public CustDetails searchById(@PathVariable String custName) {
		return dao.searchByCustName(custName);
	}
	
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value="/bookOrder")
	public String bookOrder(@RequestBody Order booking) {
		return dao.bookOrder(booking);
	}
	

//	@CrossOrigin(origins = "http://localhost:4200")
//	@RequestMapping(value="/showUserBookings/{id}")
//	public List<Order> showBookings(@PathVariable int id) { noneed here
//		return dao.userBooking(id);
//	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/searchByBookId/{id}")
	public Order searchByBookingId(@PathVariable int id) {
		return dao.searchBooking(id);
	}

}
