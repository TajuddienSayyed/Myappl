package com.example.demo;

import java.sql.Date;

public class Order {
	private int orderId;
	private int userId;
	private int vendorID;
	private Date orderDate;
	private String orderName;
	private String orderStatus;
	private double price;
	
	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public int getVendorID() {
		return vendorID;
	}


	public void setVendorID(int vendorID) {
		this.vendorID = vendorID;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}


	public String getOrderName() {
		return orderName;
	}


	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}


	public String getOrderStatus() {
		return orderStatus;
	}


	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}
	

	public Order(int orderId, int userId, int vendorID, Date orderDate, String orderName, String orderStatus,
			double price) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.vendorID = vendorID;
		this.orderDate = orderDate;
		this.orderName = orderName;
		this.orderStatus = orderStatus;
		this.price = price;
	}


	public Order() {}
	
}
