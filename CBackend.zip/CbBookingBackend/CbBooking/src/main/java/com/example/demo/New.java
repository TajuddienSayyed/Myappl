package com.example.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class New {

    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/weather";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) throws FileNotFoundException {
        // Sample list data
//        List<String> dataList = /* your list data */;
   	 String data;
  	  Scanner s = new Scanner(new File("C:/Users/stajuddien/Downloads/city.txt"));
  	    List<String> list = new ArrayList<String>();
  	    while (s.hasNext()){
  	        list.add(s.nextLine());

  	    }

        try {
            // Establishing a connection to the MySQL database
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Iterating through the list data and inserting into the database
//            for (int i = 0; i < list.size(); i++){
//            	do {
                // Prepare the SQL INSERT statement
                String sql = "INSERT INTO city (SNO,CityName,MondayTemp,TuesdayTemp,WednesdayTemp,ThursdayTemp,FridayTemp,SaturdayTemp,SundayTemp) VALUES (?,?,?,?,?,?,?,?,?)";

                // Create a PreparedStatement object to execute the SQL statement
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                for (int i = 0; i < list.size(); i++){
                        System.out.println(list.get(i));
                }
                //System.out.println(list.get());

                // Set values for parameters in the SQL statement (assuming data is of String type)
                preparedStatement.setString(1, list.get(0));
//                preparedStatement.setString(2, list.get(1));
//                preparedStatement.setString(3, list.get(2));
//                preparedStatement.setString(4, list.get(3));
//                preparedStatement.setString(5, list.get(4));
//                preparedStatement.setString(6, list.get(5));
//                preparedStatement.setString(7, list.get(6));
//                preparedStatement.setString(8, list.get(7));
//                preparedStatement.setString(9, list.get(8)); // Replace 1, 2, ... with the corresponding column indices
                // Set other parameters if you have more columns

                // Execute the SQL INSERT statement
                preparedStatement.executeUpdate();

                // Close the PreparedStatement
                preparedStatement.close();
//          	}//while(list.get(i) != null);
//            }

            // Close the connection
            connection.close();
            
            System.out.println("Data transferred successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
