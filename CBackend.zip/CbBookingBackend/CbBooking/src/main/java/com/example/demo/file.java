package com.example.demo;

import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.ArrayList;
import java.util.Scanner; // Import the Scanner class to read text files

public class file {
  public static void main(String[] args) throws FileNotFoundException {
	  String data;
	  Scanner s = new Scanner(new File("C:/Users/stajuddien/Downloads/city.txt"));
	    ArrayList<String> list = new ArrayList<String>();
	    while (s.hasNext()){
	        list.add(s.next());

	    }
	    //list<String> city = Arrays.asList("Boston", "San Diego", "Las Vegas", "Houston", "Miami", "Austin");  
	  //iterate list using for loop  
	  for (int i = 0; i < list.size(); i++)   
	  {  
	  //prints the elements of the List  
	  System.out.println(list.get(i));  
	  }  
//    try {
//      File myObj = new File("C:/Users/stajuddien/Downloads/city.txt");
//      Scanner myReader = new Scanner(myObj);
//      while (myReader.hasNextLine()) {
//         data = myReader.nextLine();
//        System.out.println(data);
//      }
//      myReader.close();
//    } catch (FileNotFoundException e) {
//      System.out.println("An error occurred.");
//      e.printStackTrace();
//    }
//	    for(int i=0;i<=s.hasNext();i++){
//		    System.out.println(list);
//	    }
//System.out.println(list);

    s.close();
  }
}