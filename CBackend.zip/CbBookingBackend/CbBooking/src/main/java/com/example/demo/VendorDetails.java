package com.example.demo;

public class VendorDetails {
	private int vendorId;
	private String vendoruserName;
	private String vendorpassword;
	private String vendorfirstName;
	private String vendorlastName;
	
	
	public int getVendorId() {
		return vendorId;
	}


	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}


	public String getVendoruserName() {
		return vendoruserName;
	}


	public void setVendoruserName(String vendoruserName) {
		this.vendoruserName = vendoruserName;
	}


	public String getVendorpassword() {
		return vendorpassword;
	}


	public void setVendorpassword(String vendorpassword) {
		this.vendorpassword = vendorpassword;
	}


	public String getVendorfirstName() {
		return vendorfirstName;
	}


	public void setVendorfirstName(String vendorfirstName) {
		this.vendorfirstName = vendorfirstName;
	}


	public String getVendorlastName() {
		return vendorlastName;
	}


	public void setVendorlastName(String vendorlastName) {
		this.vendorlastName = vendorlastName;
	}

	public VendorDetails(int vendorId, String vendoruserName, String vendorpassword, String vendorfirstName,
			String vendorlastName) {
		super();
		this.vendorId = vendorId;
		this.vendoruserName = vendoruserName;
		this.vendorpassword = vendorpassword;
		this.vendorfirstName = vendorfirstName;
		this.vendorlastName = vendorlastName;
	}
	public VendorDetails() {}
}
