package com.example.demo;

import java.sql.Date;

public class OrderHistory {
	private int histId;
	private Date deliveryDate;
	private int custId;
	private int orderId;
	private String orderStatus;
	private double totalAmount;
	public int getHistId() {
		return histId;
	}
	public void setHistId(int histId) {
		this.histId = histId;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public OrderHistory(int histId, Date deliveryDate, int custId, int orderId, String orderStatus,
			double totalAmount) {
		super();
		this.histId = histId;
		this.deliveryDate = deliveryDate;
		this.custId = custId;
		this.orderId = orderId;
		this.orderStatus = orderStatus;
		this.totalAmount = totalAmount;
	}
	
	public OrderHistory() {}
	

}
